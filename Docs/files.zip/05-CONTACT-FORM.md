# Module 5: Contact Form & Email Integration

**Goal**: Build a working contact form that sends real emails

**Time**: ~2 hours

---

## What You'll Build

A professional contact form with:
- Name, email, and message inputs
- Form validation
- Real email sending (EmailJS + Hostinger)
- Loading states
- Success/error messages
- Form reset after submission

---

## Part 1: Setting Up EmailJS

### Step 1: Create EmailJS Account

1. Go to [https://www.emailjs.com](https://www.emailjs.com)
2. Click **"Sign Up Free"**
3. Sign up with email or Google/GitHub
4. Verify your email address

---

### Step 2: Connect Your Email Service

#### For Hostinger Email:

1. In EmailJS dashboard, click **"Email Services"**
2. Click **"Add New Service"**
3. Select **"Custom Service"** or **"SMTP"**
4. Fill in:
   - **Service Name**: Hostinger Email
   - **SMTP Server**: `smtp.hostinger.com`
   - **Port**: `465`
   - **Username**: Your full Hostinger email
   - **Password**: Your email password
   - **Secure**: Check "Use SSL"
   - **From Email**: Your Hostinger email
   - **From Name**: Your name
5. Click **"Create Service"**
6. Test the connection

**📝 Save your Service ID** (looks like: `service_abc123`)

---

### Step 3: Create Email Template

1. Click **"Email Templates"**
2. Click **"Create New Template"**
3. Set up template:

**Subject:**
```
New Contact from {{from_name}}
```

**Content:**
```
You received a new message from your website.

Name: {{from_name}}
Email: {{reply_to}}

Message:
{{message}}

---
Sent from your portfolio contact form
```

4. Click **"Save"**

**📝 Save your Template ID** (looks like: `template_xyz789`)

---

### Step 4: Get Your Public Key

1. Click **"Account"** or your profile
2. Find **"Public Key"** or **"API Keys"**
3. **📝 Copy your Public Key** (looks like: `abcXYZ123_abc`)

---

### Step 5: Test EmailJS

In your template, click **"Test It"**:
- Fill in test data
- Send test email
- Check your inbox

✅ If test email arrives, you're ready!

---

## Part 2: Install EmailJS in Your Project

### Stop Dev Server

In terminal, press **Ctrl + C**

### Install EmailJS Package

```bash
npm install @emailjs/browser
```

Wait 10-30 seconds for installation.

### Restart Dev Server

```bash
npm run dev
```

---

## Part 3: Build the Contact Form

### Create Contact Form Component

**File**: `src/components/ContactForm.jsx`

```jsx
import { useState } from 'react'
import emailjs from '@emailjs/browser'
import './ContactForm.css'

function ContactForm() {
  // Form data state
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  })

  // Status states
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitStatus, setSubmitStatus] = useState(null)

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prevData => ({
      ...prevData,
      [name]: value
    }))
  }

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault()
    
    // Validation
    if (!formData.name || !formData.email || !formData.message) {
      alert('Please fill in all fields!')
      return
    }

    setIsSubmitting(true)
    setSubmitStatus(null)

    try {
      // Send email using EmailJS
      await emailjs.send(
        'YOUR_SERVICE_ID',      // ← Replace with your Service ID
        'YOUR_TEMPLATE_ID',     // ← Replace with your Template ID
        {
          from_name: formData.name,
          reply_to: formData.email,
          message: formData.message
        },
        'YOUR_PUBLIC_KEY'       // ← Replace with your Public Key
      )

      // Success!
      setSubmitStatus('success')
      setFormData({ name: '', email: '', message: '' })
      
    } catch (error) {
      console.error('Email send failed:', error)
      setSubmitStatus('error')
      
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="contact-form-container">
      <h2>Get In Touch</h2>
      <p className="contact-subtitle">
        Have a question or want to work together? Send me a message!
      </p>

      <form onSubmit={handleSubmit} className="contact-form">
        {/* Name Input */}
        <div className="form-group">
          <label htmlFor="name">Your Name</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="John Doe"
            disabled={isSubmitting}
          />
        </div>

        {/* Email Input */}
        <div className="form-group">
          <label htmlFor="email">Your Email</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="john@example.com"
            disabled={isSubmitting}
          />
        </div>

        {/* Message Input */}
        <div className="form-group">
          <label htmlFor="message">Your Message</label>
          <textarea
            id="message"
            name="message"
            value={formData.message}
            onChange={handleChange}
            placeholder="Your message here..."
            rows="5"
            disabled={isSubmitting}
          />
        </div>

        {/* Submit Button */}
        <button 
          type="submit" 
          className="submit-button"
          disabled={isSubmitting}
        >
          {isSubmitting ? 'Sending...' : 'Send Message'}
        </button>

        {/* Success Message */}
        {submitStatus === 'success' && (
          <div className="status-message success">
            ✅ Message sent successfully! I'll get back to you soon.
          </div>
        )}

        {/* Error Message */}
        {submitStatus === 'error' && (
          <div className="status-message error">
            ❌ Oops! Something went wrong. Please try again.
          </div>
        )}
      </form>
    </div>
  )
}

export default ContactForm
```

**⚠️ IMPORTANT**: Replace the three placeholders with YOUR actual IDs:
- `YOUR_SERVICE_ID`
- `YOUR_TEMPLATE_ID`
- `YOUR_PUBLIC_KEY`

---

### Style the Contact Form

**File**: `src/components/ContactForm.css`

```css
.contact-form-container {
  max-width: 600px;
  margin: 3rem auto;
  padding: 2rem;
  background: white;
  border-radius: 12px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.contact-form-container h2 {
  text-align: center;
  color: #333;
  margin-bottom: 0.5rem;
}

.contact-subtitle {
  text-align: center;
  color: #666;
  margin-bottom: 2rem;
}

.contact-form {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.form-group label {
  font-weight: 500;
  color: #333;
}

.form-group input,
.form-group textarea {
  padding: 0.75rem;
  border: 2px solid #ddd;
  border-radius: 8px;
  font-size: 1rem;
  font-family: inherit;
  transition: border-color 0.3s;
}

.form-group input:focus,
.form-group textarea:focus {
  outline: none;
  border-color: #646cff;
  box-shadow: 0 0 0 3px rgba(100, 108, 255, 0.1);
}

.form-group input:disabled,
.form-group textarea:disabled {
  background-color: #f5f5f5;
  cursor: not-allowed;
}

.form-group textarea {
  resize: vertical;
  min-height: 120px;
}

.submit-button {
  padding: 1rem 2rem;
  background-color: #646cff;
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 1rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
}

.submit-button:hover:not(:disabled) {
  background-color: #535bf2;
  transform: translateY(-2px);
  box-shadow: 0 5px 15px rgba(100, 108, 255, 0.3);
}

.submit-button:disabled {
  background-color: #ccc;
  cursor: not-allowed;
}

.status-message {
  padding: 1rem;
  border-radius: 8px;
  text-align: center;
  font-weight: 500;
  animation: slideIn 0.3s ease;
}

.status-message.success {
  background-color: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
}

.status-message.error {
  background-color: #f8d7da;
  color: #721c24;
  border: 1px solid #f5c6cb;
}

@keyframes slideIn {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
```

---

### Add Form to Your App

**File**: `src/App.jsx`

```jsx
import ContactForm from './components/ContactForm'

function App() {
  return (
    <div className="app">
      {/* Your other components */}
      
      <ContactForm />
    </div>
  )
}

export default App
```

---

## Part 4: Testing Your Form

### Test Checklist

1. ✅ Fill in all fields
2. ✅ Click "Send Message"
3. ✅ Button shows "Sending..."
4. ✅ Success message appears
5. ✅ Form clears
6. ✅ **Check your email inbox!**

### If Email Doesn't Arrive

**Check 1**: EmailJS Dashboard Test
- Test directly in EmailJS
- Does test email work?

**Check 2**: Console Errors
- Press F12
- Look for red errors
- Share error message

**Check 3**: IDs Match
- Service ID correct?
- Template ID correct?
- Public Key correct?

**Check 4**: Template Variables
- Template uses `{{from_name}}`?
- Template uses `{{reply_to}}`?
- Template uses `{{message}}`?

**Check 5**: Spam Folder
- Check spam/junk folder
- First emails often go to spam

---

## Understanding the Code

### Form State Management

```jsx
const [formData, setFormData] = useState({
  name: '',
  email: '',
  message: ''
})
```

**Why one object?**
- All form data in one place
- Easy to reset: `setFormData({ name: '', email: '', message: '' })`
- Cleaner than three separate states

---

### The handleChange Function

```jsx
const handleChange = (e) => {
  const { name, value } = e.target
  setFormData(prevData => ({
    ...prevData,
    [name]: value
  }))
}
```

**This one function handles ALL inputs!**

How?
1. Gets input's `name` attribute
2. Gets input's `value` (what user typed)
3. Updates only that field in formData
4. Keeps all other fields unchanged

See [Module 6 - React Concepts](./06-REACT-CONCEPTS.md) for detailed explanation!

---

### Async/Await for Email Sending

```jsx
const handleSubmit = async (e) => {
  try {
    await emailjs.send(...)
    // Success code
  } catch (error) {
    // Error handling
  }
}
```

**Why async/await?**
- Email sending takes time
- `await` waits for completion
- `try/catch` handles errors gracefully

---

### Loading States

```jsx
const [isSubmitting, setIsSubmitting] = useState(false)

// While sending
<button disabled={isSubmitting}>
  {isSubmitting ? 'Sending...' : 'Send Message'}
</button>
```

**Prevents:**
- Multiple submissions
- User confusion
- Duplicate emails

---

## Common Issues & Solutions

### Issue 1: 412 Error (Gmail)

**Problem**: Gmail's security blocking EmailJS

**Solution**: Use Hostinger email with SMTP settings

---

### Issue 2: Template Variables Not Working

**Problem**: Email arrives but shows `{{from_name}}` literally

**Solution**: Check template variable names match exactly:
```jsx
// In code
{
  from_name: formData.name,    // Must match template
  reply_to: formData.email,
  message: formData.message
}
```

---

### Issue 3: Form Doesn't Clear

**Problem**: After submission, form still has data

**Check**: Success handler includes:
```jsx
setFormData({ name: '', email: '', message: '' })
```

---

### Issue 4: No Error Message

**Problem**: Form fails silently

**Add**: Better error logging:
```jsx
catch (error) {
  console.error('Full error:', error)
  console.error('Error text:', error.text)
  setSubmitStatus('error')
}
```

---

## Advanced Improvements

### Add Email Validation

```jsx
const validateEmail = (email) => {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return regex.test(email)
}

// In handleSubmit
if (!validateEmail(formData.email)) {
  alert('Please enter a valid email!')
  return
}
```

### Add Character Counter

```jsx
<textarea
  value={formData.message}
  onChange={handleChange}
  maxLength="500"
/>
<p>{formData.message.length} / 500 characters</p>
```

### Add Field-Specific Errors

```jsx
const [errors, setErrors] = useState({})

// Validation
const errors = {}
if (!formData.name) errors.name = 'Name is required'
if (!formData.email) errors.email = 'Email is required'
setErrors(errors)

// Display
{errors.name && <span className="error">{errors.name}</span>}
```

---

## Security Best Practices

### Don't Commit API Keys

**Bad** ❌:
```jsx
const PUBLIC_KEY = 'abc123...'  // Hardcoded!
```

**Better** ✅:
```jsx
// Use environment variables
const PUBLIC_KEY = import.meta.env.VITE_EMAILJS_PUBLIC_KEY
```

Create `.env` file:
```
VITE_EMAILJS_PUBLIC_KEY=abc123...
VITE_EMAILJS_SERVICE_ID=service_...
VITE_EMAILJS_TEMPLATE_ID=template_...
```

Add `.env` to `.gitignore`!

---

## Testing Checklist

- [ ] Form renders correctly
- [ ] All inputs work
- [ ] Validation works
- [ ] Submit button shows loading state
- [ ] Success message appears
- [ ] Error handling works
- [ ] Form resets after submission
- [ ] Email actually arrives
- [ ] Email contains correct data
- [ ] Works on mobile

---

## What You've Learned

✅ Setting up EmailJS
✅ Creating contact forms
✅ Form state management
✅ Input validation
✅ Async/await for API calls
✅ Error handling
✅ Loading states
✅ Email integration

---

## Practice Exercises

1. **Add a phone number field**
   - Optional field
   - Phone number validation

2. **Add subject dropdown**
   - "General Inquiry"
   - "Business Proposal"
   - "Bug Report"

3. **Add honeypot spam protection**
   - Hidden field
   - Reject if filled

---

## What's Next?

✅ Working contact form
✅ Real email sending
✅ Professional user experience

**Next**: [Module 6 - Final Polish & Deployment](./06-DEPLOYMENT.md)

---

## Quick Reference

### EmailJS Setup
```
1. Create account
2. Add email service (SMTP)
3. Create template
4. Get Service ID, Template ID, Public Key
5. Test in dashboard
```

### Form Pattern
```jsx
// State
const [formData, setFormData] = useState({ ... })

// Handler
const handleChange = (e) => {
  const { name, value } = e.target
  setFormData(prev => ({ ...prev, [name]: value }))
}

// Input
<input name="email" value={formData.email} onChange={handleChange} />
```

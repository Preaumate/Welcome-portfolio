# Module 1: Environment Setup

**Goal**: Install all necessary tools to start React development

**Time**: ~30 minutes

---

## What You'll Install

1. Node.js & npm
2. VS Code
3. Git
4. GitHub Desktop (optional)
5. VS Code Extensions

---

## Step 1: Install Node.js

Node.js is required to run React development tools.

### Installation

1. Go to [https://nodejs.org](https://nodejs.org)
2. Download the **LTS version** (Long Term Support)
3. Run the installer
4. Accept all defaults
5. **Restart your computer** (important!)

### Verify Installation

Open Terminal (Mac) or Command Prompt (Windows):

```bash
node --version
# Should show: v20.x.x or similar

npm --version
# Should show: 10.x.x or similar
```

✅ **Success**: You see version numbers

---

## Step 2: Install VS Code

VS Code is your code editor.

### Installation

1. Go to [https://code.visualstudio.com](https://code.visualstudio.com)
2. Download for your operating system
3. Install with default settings
4. Open VS Code

### Essential Extensions

Click the Extensions icon (4 squares) and install:

1. **ES7+ React/Redux/React-Native snippets**
   - Provides shortcuts for React code

2. **Prettier - Code formatter**
   - Auto-formats your code

3. **ESLint**
   - Catches errors as you type

---

## Step 3: Install Git

Git is for version control (saving your code history).

### Installation

1. Go to [https://git-scm.com/downloads](https://git-scm.com/downloads)
2. Download and install
3. During installation (Windows): select "Use Visual Studio Code as Git's default editor"

### Configure Git

Open Terminal/Command Prompt:

```bash
git config --global user.name "Your Name"
git config --global user.email "your-email@example.com"
```

Replace with YOUR actual name and email!

### Verify Installation

```bash
git --version
# Should show: git version 2.x.x
```

---

## Step 4: Install GitHub Desktop (Optional)

Makes Git easier with a visual interface.

1. Go to [https://desktop.github.com](https://desktop.github.com)
2. Download and install
3. Sign in with your GitHub account

---

## Step 5: Create GitHub Account

If you don't have one:

1. Go to [https://github.com](https://github.com)
2. Sign up for free
3. Verify your email

---

## Verification Checklist

Open VS Code, then open Terminal (View → Terminal):

```bash
node --version    # ✅ Shows version
npm --version     # ✅ Shows version
git --version     # ✅ Shows version
```

---

## Troubleshooting

### "Command not found" errors

**Solution**: Restart your computer after installing

### npm is slow or hangs

**Solution**: Check your internet connection

### Git config fails

**Solution**: Make sure you use quotes around your name/email

---

## What's Next?

✅ All tools installed
✅ Git configured
✅ VS Code ready

**Next**: [Module 2 - Creating Your First React App](./02-FIRST-REACT-APP.md)

---

## Quick Reference

### Opening Terminal in VS Code

- Menu: `View → Terminal`
- Shortcut: `` Ctrl + ` `` (Windows/Linux) or `` Cmd + ` `` (Mac)

### Checking Versions

```bash
node --version
npm --version
git --version
```

### Git Configuration

```bash
# Set your name
git config --global user.name "Your Name"

# Set your email
git config --global user.email "your@email.com"

# Verify settings
git config --list
```

# Module 3: Git & GitHub Basics

**Goal**: Learn version control and backup your code online

**Time**: ~45 minutes

---

## Why Git & GitHub?

**Git** = Version control system (saves history of your code)
**GitHub** = Website that stores your code online

Think of it like:
- Git = Save button for your project
- GitHub = Google Drive for code

---

## Understanding Git Workflow

```
Working Directory → Staging Area → Repository → GitHub

Your files     →   git add    →  git commit  →  git push
```

---

## Initial Setup (One Time Only)

### Configure Git

```bash
git config --global user.name "Your Name"
git config --global user.email "your@email.com"
```

### Verify Configuration

```bash
git config --list
```

---

## Git Basics in Your Project

### Check Git Status

```bash
git status
```

Shows:
- Modified files (red)
- Staged files (green)
- Untracked files

### Stage Files (Prepare to Save)

```bash
# Stage all files
git add .

# Stage specific file
git add src/App.jsx
```

### Commit (Save a Version)

```bash
git commit -m "Your descriptive message here"
```

**Good commit messages:**
- ✅ "Added welcome dialog component"
- ✅ "Fixed button styling issue"
- ✅ "Integrated EmailJS for contact form"

**Bad commit messages:**
- ❌ "stuff"
- ❌ "changes"
- ❌ "asdf"

---

## Creating GitHub Repository

### Method 1: GitHub Website

1. Go to [github.com](https://github.com)
2. Click **"+" icon** → "New repository"
3. Repository name: `welcome-portfolio`
4. Description: "My first React portfolio website"
5. **Don't** check "Initialize with README"
6. Click **"Create repository"**

### Method 2: GitHub Desktop

1. Open GitHub Desktop
2. File → Add Local Repository
3. Choose your project folder
4. Click "Publish repository"

---

## Connecting Local Project to GitHub

After creating the repository on GitHub, connect your local project:

```bash
# Add remote repository
git remote add origin https://github.com/YOUR-USERNAME/welcome-portfolio.git

# Rename branch to main (if needed)
git branch -M main

# Push your code
git push -u origin main
```

Replace `YOUR-USERNAME` with your actual GitHub username!

---

## The Daily Git Workflow

This is what you'll do constantly:

### 1. Make Changes
Edit your code in VS Code

### 2. Check What Changed
```bash
git status
```

### 3. Stage Changes
```bash
git add .
```

### 4. Commit with Message
```bash
git commit -m "Added contact form component"
```

### 5. Push to GitHub
```bash
git push
```

---

## Understanding Git Commands

### `git status`
**What it does**: Shows current state of your repository

**When to use**: Before committing, to see what's changed

**Output example**:
```
Modified:   src/App.jsx
Untracked:  src/components/Button.jsx
```

### `git add .`
**What it does**: Stages all changed files

**The dot (.)** means "all files in current directory"

**Alternative**:
```bash
git add src/App.jsx          # Stage one file
git add src/components/      # Stage a folder
```

### `git commit -m "message"`
**What it does**: Saves a snapshot with a description

**The -m flag**: Lets you add message in the command

**Without -m**: Opens text editor (confusing for beginners)

### `git push`
**What it does**: Uploads commits to GitHub

**First time**: Use `git push -u origin main`

**After that**: Just `git push`

### `git pull`
**What it does**: Downloads changes from GitHub

**When to use**: 
- Working on multiple computers
- Collaborating with others
- Edited directly on GitHub

---

## Common Git Scenarios

### Scenario 1: Made Changes, Want to Save

```bash
git add .
git commit -m "Updated button styles"
git push
```

### Scenario 2: Check What's Different

```bash
git status          # See which files changed
git diff            # See exact changes (press 'q' to exit)
```

### Scenario 3: Undo Unstaged Changes

```bash
git checkout -- src/App.jsx    # Undo changes to one file
git checkout -- .              # Undo all unstaged changes
```

⚠️ **Warning**: This deletes your changes!

### Scenario 4: Forgot to Add a File

```bash
git add forgotten-file.jsx
git commit --amend --no-edit    # Add to previous commit
```

---

## Viewing Your History

### See Commit History

```bash
git log
```

Shows all commits with:
- Commit ID
- Author
- Date
- Message

**Press 'q' to exit**

### Compact History

```bash
git log --oneline
```

Shows one line per commit.

---

## Working with Branches (Advanced)

Branches let you work on features without affecting main code.

### Create Branch

```bash
git branch feature-name
git checkout feature-name
```

Or combined:
```bash
git checkout -b feature-name
```

### Switch Between Branches

```bash
git checkout main              # Switch to main
git checkout feature-name      # Switch to feature
```

### Merge Branch

```bash
git checkout main              # Go to main branch
git merge feature-name         # Merge feature into main
```

---

## Common Issues & Solutions

### "Not a git repository"

**Problem**: You're in the wrong folder

**Solution**:
```bash
cd /path/to/your/project
# Or in your case:
cd welcome-portfolio
```

### "Failed to push"

**Problem**: GitHub has changes you don't have locally

**Solution**:
```bash
git pull                # Download changes
git push                # Try pushing again
```

### "Merge Conflict"

**Problem**: Same line edited in two places

**Solution**:
1. Open the conflicted file
2. Look for `<<<<<<<`, `=======`, `>>>>>>>`
3. Decide which version to keep
4. Remove the conflict markers
5. Save, add, commit

---

## .gitignore File

Tells Git which files to ignore.

Your project already has one! It ignores:
- `node_modules/` (too big, not needed in repo)
- `dist/` (build output)
- `.env` (secret keys)

### Adding to .gitignore

Edit `.gitignore` file:
```
# Ignore all .log files
*.log

# Ignore specific folder
my-secret-folder/

# Ignore specific file
config.secret.js
```

---

## Best Practices

### Commit Often
- Small, focused commits
- Easier to track changes
- Easier to undo if needed

### Write Good Messages
```bash
# Good ✅
git commit -m "Add validation to contact form"
git commit -m "Fix button hover animation"

# Bad ❌
git commit -m "changes"
git commit -m "stuff"
```

### Push Regularly
- Backs up your work
- Others can see your progress
- Works as cloud backup

### Don't Commit Secrets
Never commit:
- API keys
- Passwords
- Email credentials
- Personal info

Use `.gitignore` and environment variables!

---

## GitHub Repository Features

### README.md
- First file visitors see
- Describes your project
- Written in Markdown

### Releases
- Mark specific versions
- Create downloadable packages

### Issues
- Track bugs
- Feature requests
- To-do items

### Pull Requests
- Propose changes
- Code review
- Collaboration

---

## Practice Exercise

1. Make a change to `App.jsx`
2. Check status: `git status`
3. Stage changes: `git add .`
4. Commit: `git commit -m "Practice commit"`
5. Push: `git push`
6. Visit your GitHub repository
7. See your commit appear!

---

## What You've Learned

✅ Git basics (add, commit, push)
✅ Created GitHub repository
✅ Connected local project to GitHub
✅ The git workflow
✅ Common commands and troubleshooting

---

## What's Next?

✅ Project under version control
✅ Code backed up on GitHub
✅ Ready to collaborate

**Next**: [Module 4 - Building Interactive Components](./04-BUILDING-COMPONENTS.md)

---

## Quick Command Reference

```bash
# Check status
git status

# Stage all changes
git add .

# Commit with message
git commit -m "Your message"

# Push to GitHub
git push

# Pull from GitHub
git pull

# View history
git log --oneline

# Undo unstaged changes
git checkout -- .
```

---

## GitHub Repository URL

Your repository will be at:
```
https://github.com/YOUR-USERNAME/welcome-portfolio
```

Replace `YOUR-USERNAME` with your actual username!

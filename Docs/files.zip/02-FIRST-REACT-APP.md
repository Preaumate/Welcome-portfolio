# Module 2: Your First React App

**Goal**: Create and run a React application

**Time**: ~45 minutes

---

## Creating Your Project

### Step 1: Navigate to Your Projects Folder

Open Terminal in VS Code:

```bash
cd Desktop
# Or wherever you want to keep your project
```

### Step 2: Create React Project with Vite

```bash
npm create vite@latest welcome-portfolio -- --template react
```

When prompted:
- Select framework: **React**
- Select variant: **JavaScript**

### Step 3: Install Dependencies

```bash
cd welcome-portfolio
npm install
```

This installs all required packages (takes 30-60 seconds).

### Step 4: Start Development Server

```bash
npm run dev
```

You should see:
```
VITE v7.x.x  ready in 295 ms
➜  Local:   http://localhost:5173/
```

### Step 5: Open in Browser

Hold **Ctrl** (Windows) or **Cmd** (Mac) and click the link, OR:
- Open browser manually
- Go to `http://localhost:5173/`

🎉 **You should see the React + Vite starter page!**

---

## Understanding Your Project Structure

```
welcome-portfolio/
├── node_modules/      # Installed packages (don't touch!)
├── public/            # Static files (images, etc.)
├── src/               # YOUR CODE GOES HERE
│   ├── App.jsx       # Main component
│   ├── App.css       # App styles
│   ├── main.jsx      # Entry point
│   └── index.css     # Global styles
├── index.html         # HTML template
├── package.json       # Project configuration
└── vite.config.js     # Vite configuration
```

### Key Files

**`src/App.jsx`** - Your main component (where you'll build your website)

**`src/main.jsx`** - Connects React to the HTML

**`index.html`** - The HTML file that loads everything

**`package.json`** - Lists dependencies and scripts

---

## Making Your First Changes

### Exercise 1: Edit the Title

1. Open `src/App.jsx`
2. Find this line:
   ```jsx
   <h1>Vite + React</h1>
   ```
3. Change it to:
   ```jsx
   <h1>Welcome to My Website!</h1>
   ```
4. **Save** (Ctrl+S / Cmd+S)
5. Check your browser - it updates automatically! 🎉

This is called **Hot Module Replacement** (HMR).

### Exercise 2: Change Button Text

Find:
```jsx
<button onClick={() => setCount((count) => count + 1)}>
  count is {count}
</button>
```

Change to:
```jsx
<button onClick={() => setCount((count) => count + 1)}>
  I've been clicked {count} times!
</button>
```

### Exercise 3: Add Personal Introduction

Find the paragraph at the bottom and replace it:

```jsx
<p className="read-the-docs">
  Hi! I'm [YOUR NAME], and I'm learning React web development.
</p>
<p className="read-the-docs">
  This is my first website built from scratch!
</p>
```

---

## Understanding the Code

### What is JSX?

The HTML-like code in JavaScript files is called **JSX**.

```jsx
// This looks like HTML but it's JavaScript!
<h1>Hello World</h1>
```

JSX lets you write UI components that look like HTML.

### Component Structure

```jsx
function App() {
  // JavaScript code here
  const [count, setCount] = useState(0)
  
  // Return JSX (what to display)
  return (
    <div>
      <h1>Hello</h1>
    </div>
  )
}
```

**Key parts:**
1. Function that returns JSX
2. Uses `useState` for interactive data
3. Exported at the bottom: `export default App`

---

## Development Server Commands

### Start Server
```bash
npm run dev
```

### Stop Server
Press **Ctrl + C** in the terminal

### Restart Server
1. Stop it (Ctrl + C)
2. Start again: `npm run dev`

---

## Common Issues & Solutions

### Port Already in Use

**Error**: `Port 5173 is already in use`

**Solution**: 
- You might have the server running in another terminal
- Close other terminals or use Ctrl+C to stop previous servers

### Cannot Find Module

**Error**: `Cannot find module 'react'`

**Solution**:
```bash
npm install
```

### Page Shows "Cannot Connect"

**Solution**:
- Make sure dev server is running
- Check the URL is exactly `http://localhost:5173/`
- Try refreshing the page

---

## Understanding Hot Reload

When you save a file, Vite automatically:
1. Detects the change
2. Updates the code
3. Refreshes your browser
4. **Keeps your app state** (like the counter value!)

This is called **Hot Module Replacement** - it's what makes React development fast!

---

## File Organization Tips

### The `src` Folder

This is where ALL your code goes:
- Components
- Styles
- Images
- Helper functions

### The `public` Folder

For files that don't need processing:
- Favicon
- Static images
- robots.txt

---

## What You've Learned

✅ How to create a React project with Vite
✅ Project structure and key files
✅ How to start/stop the development server
✅ Making changes and seeing them live
✅ Basic JSX syntax

---

## Practice Challenges

1. **Change the logos**: Try adding different images
2. **Add more paragraphs**: Practice adding more JSX elements
3. **Experiment with the counter**: Try starting from a different number
4. **Break something**: Delete a closing tag and see what error you get (then fix it!)

---

## What's Next?

✅ React app created and running
✅ Made your first changes
✅ Understand basic project structure

**Next**: [Module 3 - Git & GitHub Basics](./03-GIT-GITHUB.md)

---

## Quick Commands Reference

```bash
# Create project
npm create vite@latest project-name -- --template react

# Navigate to project
cd project-name

# Install dependencies
npm install

# Start dev server
npm run dev

# Stop server
Ctrl + C
```

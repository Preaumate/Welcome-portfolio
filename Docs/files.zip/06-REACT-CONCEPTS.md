# Understanding React Concepts - Deep Dive

**A comprehensive explanation of the core React concepts you've been using**

---

## Table of Contents

1. [useState Hook](#usestate-hook)
2. [Props](#props)
3. [The map() Function](#the-map-function)
4. [Event Handling](#event-handling)
5. [Conditional Rendering](#conditional-rendering)
6. [The handleChange Pattern](#the-handlechange-pattern)

---

## useState Hook

### What is useState?

`useState` is a React Hook that lets components "remember" values between renders.

**Think of it as**: Giving your component a memory.

### The Problem Without useState

```jsx
function Counter() {
  let count = 0  // This resets to 0 every time!
  
  return (
    <button onClick={() => count = count + 1}>
      Count: {count}
    </button>
  )
}
```

❌ **This doesn't work** because `count` resets on every render.

### The Solution: useState

```jsx
import { useState } from 'react'

function Counter() {
  const [count, setCount] = useState(0)
  
  return (
    <button onClick={() => setCount(count + 1)}>
      Count: {count}
    </button>
  )
}
```

✅ **This works** because React remembers the count value!

---

### Breaking Down the Syntax

```jsx
const [count, setCount] = useState(0)
//     ↑      ↑           ↑
//     │      │           └─ Initial value
//     │      │
//     │      └─ Function to update count
//     │
//     └─ Current value of count
```

**Components**:
1. `count` - The current value (read it, display it)
2. `setCount` - Function to update count (call it to change the value)
3. `useState(0)` - Creates state with initial value of 0

---

### How useState Works

```jsx
// First render
const [count, setCount] = useState(0)  // count = 0

// User clicks button
setCount(1)

// React re-renders component
const [count, setCount] = useState(0)  // count = 1 (React remembers!)

// User clicks again
setCount(2)

// React re-renders again
const [count, setCount] = useState(0)  // count = 2
```

**Key insight**: Each render gets a new `count` variable, but React tracks the value behind the scenes!

---

### useState with Different Data Types

#### String
```jsx
const [name, setName] = useState('')
setName('John')
```

#### Boolean
```jsx
const [isOpen, setIsOpen] = useState(false)
setIsOpen(true)
```

#### Array
```jsx
const [items, setItems] = useState([])
setItems([...items, 'new item'])
```

#### Object
```jsx
const [user, setUser] = useState({ name: '', age: 0 })
setUser({ ...user, name: 'John' })
```

---

### useState Rules

#### Rule 1: Never Modify State Directly ❌

```jsx
// WRONG
count = count + 1
items.push('new')
user.name = 'John'
```

#### Always Use the Setter Function ✅

```jsx
// CORRECT
setCount(count + 1)
setItems([...items, 'new'])
setUser({ ...user, name: 'John' })
```

**Why?** React doesn't know state changed unless you use the setter!

---

#### Rule 2: State Updates Are Asynchronous

```jsx
const [count, setCount] = useState(0)

const handleClick = () => {
  setCount(count + 1)
  console.log(count)  // Still shows 0! (old value)
}
```

The new value won't be available until the next render.

---

#### Rule 3: Call useState at Top Level

```jsx
// WRONG ❌
function App() {
  if (condition) {
    const [count, setCount] = useState(0)  // Don't put in conditionals!
  }
}

// CORRECT ✅
function App() {
  const [count, setCount] = useState(0)  // Always at the top
  
  if (condition) {
    // Use state here
  }
}
```

---

### Real Example from Your Code

```jsx
// Welcome Dialog
const [isOpen, setIsOpen] = useState(true)

if (!isOpen) return null  // If false, don't show dialog

return (
  <div>
    <button onClick={() => setIsOpen(false)}>Close</button>
  </div>
)
```

**Flow**:
1. Dialog starts open (`true`)
2. User clicks button
3. `setIsOpen(false)` called
4. React re-renders
5. `if (!isOpen) return null` - dialog disappears!

---

## Props

### What Are Props?

**Props** (properties) are how you pass data from parent to child components.

**Think of it as**: Function arguments for components.

---

### The Problem Without Props

```jsx
// Bad - hardcoded
function Card() {
  return (
    <div>
      <h3>Web Development</h3>
      <p>I'm learning React</p>
    </div>
  )
}

// Need 3 cards? Need 3 different components! 😱
function Card1() { ... }
function Card2() { ... }
function Card3() { ... }
```

---

### The Solution: Props

```jsx
// Good - reusable!
function Card({ title, description }) {
  return (
    <div>
      <h3>{title}</h3>
      <p>{description}</p>
    </div>
  )
}

// Same component, different data!
<Card title="Web Dev" description="Learning React" />
<Card title="Design" description="UI/UX" />
<Card title="Games" description="Playing on weekends" />
```

---

### Sending Props (Parent)

```jsx
// String props
<Card title="Hello" />

// Number props
<Counter initialCount={10} />

// Boolean props
<Dialog isOpen={true} />

// Function props
<Button onClick={() => alert('Clicked!')} />

// Array props
<List items={['a', 'b', 'c']} />

// Object props
<UserCard user={{ name: 'John', age: 25 }} />
```

**Rule**: Strings use quotes, everything else uses curly braces!

---

### Receiving Props (Child)

#### Method 1: Destructuring (Recommended)

```jsx
function Card({ title, description, image }) {
  return (
    <div>
      <h3>{title}</h3>
      <p>{description}</p>
    </div>
  )
}
```

#### Method 2: Props Object

```jsx
function Card(props) {
  return (
    <div>
      <h3>{props.title}</h3>
      <p>{props.description}</p>
    </div>
  )
}
```

Both work the same! Destructuring is cleaner.

---

### Default Props

```jsx
function Button({ text, variant = 'primary' }) {
  return <button className={variant}>{text}</button>
}

// If variant not provided, defaults to 'primary'
<Button text="Click" />  // variant = 'primary'
<Button text="Click" variant="secondary" />  // variant = 'secondary'
```

---

### Props Are Read-Only!

```jsx
// WRONG ❌
function Card({ title }) {
  title = "New Title"  // Don't modify props!
  return <h3>{title}</h3>
}

// CORRECT ✅
function Card({ title }) {
  const [cardTitle, setCardTitle] = useState(title)
  
  return (
    <div>
      <h3>{cardTitle}</h3>
      <button onClick={() => setCardTitle("New Title")}>
        Change
      </button>
    </div>
  )
}
```

**Why?** Props come from parent. Child shouldn't change parent's data!

---

### Props Flow: One Direction

```
Parent Component
      |
      | props flow DOWN
      ↓
Child Component
```

Data flows **down** the component tree. This is called "one-way data flow".

---

### Real Example from Your Code

```jsx
// Parent (App.jsx) sends props
<Card 
  title="Web Development"
  description="I'm learning React!"
  image="https://example.com/image.jpg"
  imageAlt="Coding"
/>

// Child (Card.jsx) receives props
function Card({ title, description, image, imageAlt }) {
  return (
    <div className="card">
      <img src={image} alt={imageAlt} />
      <h3>{title}</h3>
      <p>{description}</p>
    </div>
  )
}
```

---

### Special Prop: children

```jsx
function Box({ children }) {
  return <div className="box">{children}</div>
}

// Usage
<Box>
  <h1>Hello</h1>
  <p>This is inside!</p>
</Box>

// children = everything between <Box> and </Box>
```

---

## The map() Function

### What is map()?

`map()` is a JavaScript array method that **transforms** each item and returns a new array.

In React, we use it to turn data into components!

---

### Basic JavaScript map()

```jsx
const numbers = [1, 2, 3, 4, 5]

const doubled = numbers.map(num => num * 2)

console.log(doubled)  // [2, 4, 6, 8, 10]
```

**What happened:**
1. Takes each number
2. Multiplies by 2
3. Returns new array

---

### map() in React

Instead of transforming numbers, we transform data into JSX!

```jsx
const fruits = ['Apple', 'Banana', 'Orange']

return (
  <ul>
    {fruits.map(fruit => (
      <li>{fruit}</li>
    ))}
  </ul>
)

// Renders:
// <ul>
//   <li>Apple</li>
//   <li>Banana</li>
//   <li>Orange</li>
// </ul>
```

---

### The key Prop

When using `map()`, React needs a unique `key` for each item:

```jsx
{items.map((item, index) => (
  <div key={index}>  {/* key is required! */}
    {item}
  </div>
))}
```

**Why?** React uses `key` to track which items changed, were added, or removed.

**Best practice:**
- Use unique IDs when available: `key={item.id}`
- Use index only if items won't reorder: `key={index}`

---

### map() Breakdown

```jsx
{options.map((option, index) => (
  //        ↑       ↑
  //        │       └─ Position in array (0, 1, 2...)
  //        │
  //        └─ Current item
  
  <option key={index} value={option.value}>
    {option.label}
  </option>
))}
```

---

### Real Example from Your Code

```jsx
// Dropdown options
const skills = [
  { label: 'JavaScript', value: 'javascript' },
  { label: 'React', value: 'react' },
  { label: 'CSS', value: 'css' }
]

// Transform into <option> elements
<select>
  {skills.map((option, index) => (
    <option key={index} value={option.value}>
      {option.label}
    </option>
  ))}
</select>

// Result:
// <select>
//   <option value="javascript">JavaScript</option>
//   <option value="react">React</option>
//   <option value="css">CSS</option>
// </select>
```

---

### Common map() Patterns

#### Pattern 1: Simple List

```jsx
const names = ['Alice', 'Bob', 'Charlie']

{names.map(name => (
  <p key={name}>{name}</p>
))}
```

#### Pattern 2: Objects

```jsx
const users = [
  { id: 1, name: 'Alice', age: 25 },
  { id: 2, name: 'Bob', age: 30 }
]

{users.map(user => (
  <div key={user.id}>
    <h3>{user.name}</h3>
    <p>Age: {user.age}</p>
  </div>
))}
```

#### Pattern 3: Components

```jsx
const cards = [
  { id: 1, title: 'Card 1', text: 'Content 1' },
  { id: 2, title: 'Card 2', text: 'Content 2' }
]

{cards.map(card => (
  <Card 
    key={card.id}
    title={card.title}
    description={card.text}
  />
))}
```

---

## Event Handling

### What Are Events?

Events are things that happen in the browser: clicks, typing, hovering, etc.

React lets you "listen" for events and respond to them!

---

### Common Events

#### onClick - When clicked

```jsx
<button onClick={() => alert('Clicked!')}>
  Click Me
</button>
```

#### onChange - When input changes

```jsx
<input 
  type="text" 
  onChange={(e) => console.log(e.target.value)}
/>
```

#### onSubmit - When form submitted

```jsx
<form onSubmit={(e) => {
  e.preventDefault()
  console.log('Form submitted!')
}}>
  <button type="submit">Submit</button>
</form>
```

#### onMouseEnter / onMouseLeave - Hovering

```jsx
<div 
  onMouseEnter={() => console.log('Mouse in!')}
  onMouseLeave={() => console.log('Mouse out!')}
>
  Hover me
</div>
```

---

### Event Handler Patterns

#### Pattern 1: Inline Function

```jsx
<button onClick={() => alert('Hello')}>
  Click
</button>
```

#### Pattern 2: Separate Function

```jsx
function App() {
  const handleClick = () => {
    alert('Hello')
  }
  
  return <button onClick={handleClick}>Click</button>
}
```

#### Pattern 3: With Parameters

```jsx
function App() {
  const greet = (name) => {
    alert(`Hello, ${name}!`)
  }
  
  return (
    <button onClick={() => greet('John')}>
      Greet John
    </button>
  )
}
```

---

### The Event Object

Events come with useful information:

```jsx
<input onChange={(event) => {
  console.log(event.target.value)  // What user typed
  console.log(event.target.name)   // Input's name
}} />
```

Usually shortened to `e`:

```jsx
<input onChange={(e) => {
  console.log(e.target.value)
}} />
```

---

### Preventing Default Behavior

Some events have default browser behavior:

```jsx
<form onSubmit={(e) => {
  e.preventDefault()  // Stop page refresh!
  console.log('Form submitted')
}}>
  <button type="submit">Submit</button>
</form>
```

---

### Real Example from Your Code

```jsx
// Dropdown change handler
const handleChange = (event) => {
  const value = event.target.value  // Get selected value
  setSelectedValue(value)           // Update state
  if (onSelect) {
    onSelect(value)                 // Call parent function
  }
}

<select onChange={handleChange}>
  <option value="react">React</option>
</select>
```

**Flow:**
1. User selects "React"
2. `onChange` fires
3. `handleChange` called with event
4. `event.target.value` = "react"
5. State updates
6. Component re-renders

---

## Conditional Rendering

### What Is It?

Showing different content based on conditions.

---

### Method 1: && Operator

"If this is true, show that"

```jsx
{isLoggedIn && <p>Welcome back!</p>}

// Same as:
// if (isLoggedIn) {
//   show <p>Welcome back!</p>
// }
```

**Real example:**

```jsx
{image && (
  <div className="card-image">
    <img src={image} />
  </div>
)}

// Only shows image if image prop exists
```

---

### Method 2: Ternary Operator

"If this, show that, otherwise show something else"

```jsx
{isLoggedIn ? (
  <p>Welcome back!</p>
) : (
  <p>Please log in</p>
)}

// Same as:
// if (isLoggedIn) {
//   show "Welcome back!"
// } else {
//   show "Please log in"
// }
```

---

### Method 3: Early Return

```jsx
function WelcomeDialog() {
  const [isOpen, setIsOpen] = useState(true)
  
  if (!isOpen) return null  // Don't render anything
  
  return <div>Dialog content</div>
}
```

---

### Real Examples from Your Code

#### Example 1: Welcome Dialog

```jsx
if (!isOpen) return null

// If not open, show nothing
// If open, continue to render dialog
```

#### Example 2: Selected Text

```jsx
{selectedValue && (
  <p>You selected: {selectedValue}</p>
)}

// Only show if something is selected
```

#### Example 3: Success Message

```jsx
{submitStatus === 'success' && (
  <div className="success-message">
    Message sent!
  </div>
)}
```

---

## The handleChange Pattern

### The Complete Function

```jsx
const handleChange = (e) => {
  const { name, value } = e.target
  setFormData(prevData => ({
    ...prevData,
    [name]: value
  }))
}
```

This ONE function handles ALL form inputs! Let's break it down...

---

### Part 1: Destructuring the Event

```jsx
const { name, value } = e.target
```

**Same as:**

```jsx
const name = e.target.name
const value = e.target.value
```

**Example**: If user types "John" in name input:

```jsx
name = "name"      // The input's name attribute
value = "John"     // What the user typed
```

---

### Part 2: Your Form Inputs

```jsx
<input
  name="name"        // ← This is key!
  value={formData.name}
  onChange={handleChange}
/>

<input
  name="email"       // ← Different name
  value={formData.email}
  onChange={handleChange}
/>
```

All inputs use the SAME `handleChange`, but each has a different `name` attribute!

---

### Part 3: Updating State

```jsx
setFormData(prevData => ({
  ...prevData,
  [name]: value
}))
```

**Breaking it down:**

#### 3a: Callback Function

```jsx
setFormData(prevData => ({ ... }))
```

Uses callback to get previous state. **Why?** To safely update state based on previous value.

#### 3b: Spread Operator

```jsx
{
  ...prevData,
  [name]: value
}
```

The `...prevData` copies all existing properties.

**Example**: If `formData` is:

```jsx
{
  name: "John",
  email: "john@email.com",
  message: "Hello"
}
```

Then `...prevData` creates:

```jsx
{
  name: "John",
  email: "john@email.com",
  message: "Hello"
}
```

#### 3c: Computed Property Name

```jsx
{
  ...prevData,
  [name]: value    // ← Square brackets!
}
```

Square brackets `[name]` mean: "Use the VALUE of the name variable as the property name"

---

### Complete Example

**Current state:**

```jsx
formData = {
  name: "John",
  email: "",
  message: ""
}
```

**User types "j" in email input:**

**Step 1:** React calls `handleChange` with event

**Step 2:** Destructure
```jsx
name = "email"     // from input's name attribute
value = "j"        // what user typed
```

**Step 3:** Update state
```jsx
setFormData(prevData => ({
  ...prevData,      // Copy: name: "John", email: "", message: ""
  [name]: value     // Update: email = "j"
}))
```

**Step 4:** New formData:
```jsx
formData = {
  name: "John",       // ← Unchanged
  email: "j",         // ← Updated!
  message: ""         // ← Unchanged
}
```

---

### Why This Approach is Brilliant

#### Alternative (Bad): Three Separate Functions

```jsx
const handleNameChange = (e) => {
  setFormData({ ...formData, name: e.target.value })
}

const handleEmailChange = (e) => {
  setFormData({ ...formData, email: e.target.value })
}

const handleMessageChange = (e) => {
  setFormData({ ...formData, message: e.target.value })
}

// Repetitive! 😫
```

#### Our Approach (Good): One Function

```jsx
const handleChange = (e) => {
  const { name, value } = e.target
  setFormData(prevData => ({
    ...prevData,
    [name]: value
  }))
}

// Handles everything! ✅
```

---

### Visual Flow

```
User types in input
      ↓
onChange fires
      ↓
handleChange called
      ↓
Extract name & value
      ↓
Update that specific field
      ↓
Keep other fields unchanged
      ↓
React re-renders
      ↓
Input shows new value
```

---

## Summary

### useState
- Gives components memory
- `const [value, setValue] = useState(initial)`
- Always use setter function
- State updates trigger re-renders

### Props
- Pass data parent → child
- Read-only (don't modify)
- Use destructuring for clean code
- One-way data flow

### map()
- Transform arrays into JSX
- Always include `key` prop
- Use unique IDs when possible

### Event Handling
- onClick, onChange, onSubmit, etc.
- Event object has useful data
- Use e.preventDefault() when needed

### Conditional Rendering
- `&&` for "if true, show this"
- Ternary for "if/else"
- Early return for component-level conditionals

### handleChange Pattern
- One function handles all inputs
- Uses name attribute to identify input
- Spread operator preserves existing data
- Computed property updates specific field

---

**Next**: [Quick Reference Guide](./07-QUICK-REFERENCE.md)

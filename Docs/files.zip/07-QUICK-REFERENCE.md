# Quick Reference Guide

**Fast lookup for common patterns, commands, and code snippets**

---

## React Patterns

### Component Template

```jsx
import './ComponentName.css'

function ComponentName({ prop1, prop2 }) {
  // State
  const [value, setValue] = useState(initial)
  
  // Event handlers
  const handleClick = () => {
    // Logic here
  }
  
  // Return JSX
  return (
    <div className="component-name">
      {/* Content */}
    </div>
  )
}

export default ComponentName
```

---

### useState Patterns

```jsx
// String
const [name, setName] = useState('')

// Number
const [count, setCount] = useState(0)

// Boolean
const [isOpen, setIsOpen] = useState(false)

// Array
const [items, setItems] = useState([])

// Object
const [user, setUser] = useState({ name: '', age: 0 })
```

---

### Props Patterns

```jsx
// Passing props
<Component 
  text="Hello"
  count={5}
  onClick={handleClick}
  isActive={true}
/>

// Receiving props
function Component({ text, count, onClick, isActive }) {
  return <div>{text}</div>
}

// Default props
function Component({ variant = 'primary' }) {
  return <button className={variant}>Click</button>
}
```

---

### Conditional Rendering

```jsx
// If statement
{condition && <Component />}

// If/else
{condition ? <ComponentA /> : <ComponentB />}

// Early return
if (!isValid) return null
return <Component />

// Multiple conditions
{status === 'loading' && <Spinner />}
{status === 'error' && <ErrorMessage />}
{status === 'success' && <SuccessMessage />}
```

---

### List Rendering

```jsx
// Simple array
{items.map((item, index) => (
  <li key={index}>{item}</li>
))}

// Array of objects
{users.map(user => (
  <div key={user.id}>
    <h3>{user.name}</h3>
    <p>{user.email}</p>
  </div>
))}

// With components
{cards.map(card => (
  <Card 
    key={card.id}
    title={card.title}
    description={card.description}
  />
))}
```

---

### Event Handling

```jsx
// Click
<button onClick={() => handleClick()}>Click</button>
<button onClick={handleClick}>Click</button>

// Change
<input onChange={(e) => handleChange(e)} />
<input onChange={handleChange} />

// Submit
<form onSubmit={(e) => {
  e.preventDefault()
  handleSubmit()
}}>

// Multiple events
<div
  onClick={handleClick}
  onMouseEnter={handleMouseEnter}
  onMouseLeave={handleMouseLeave}
>
```

---

### Form Handling

```jsx
// State
const [formData, setFormData] = useState({
  name: '',
  email: '',
  message: ''
})

// Handler
const handleChange = (e) => {
  const { name, value } = e.target
  setFormData(prev => ({
    ...prev,
    [name]: value
  }))
}

// Submit
const handleSubmit = (e) => {
  e.preventDefault()
  // Process form data
}

// Input
<input
  name="email"
  value={formData.email}
  onChange={handleChange}
/>
```

---

### Array State Updates

```jsx
// Add item
setItems([...items, newItem])
setItems(prev => [...prev, newItem])

// Remove item
setItems(items.filter(item => item.id !== removeId))

// Update item
setItems(items.map(item => 
  item.id === updateId ? { ...item, name: 'New' } : item
))

// Clear all
setItems([])
```

---

### Object State Updates

```jsx
// Update one property
setUser({ ...user, name: 'John' })
setUser(prev => ({ ...prev, name: 'John' }))

// Update multiple properties
setUser({ ...user, name: 'John', age: 30 })

// Update nested property
setUser({
  ...user,
  address: { ...user.address, city: 'New York' }
})
```

---

## Git Commands

### Basic Workflow

```bash
# Check status
git status

# Stage all changes
git add .

# Stage specific file
git add src/App.jsx

# Commit with message
git commit -m "Your descriptive message"

# Push to GitHub
git push

# Pull from GitHub
git pull
```

---

### History & Info

```bash
# View commit history
git log
git log --oneline

# See what changed
git diff

# See staged changes
git diff --staged

# Show file history
git log -- src/App.jsx
```

---

### Undoing Changes

```bash
# Undo unstaged changes to file
git checkout -- src/App.jsx

# Undo all unstaged changes
git checkout -- .

# Unstage file (keep changes)
git reset HEAD src/App.jsx

# Amend last commit
git commit --amend -m "New message"
```

---

### Branches

```bash
# Create branch
git branch feature-name

# Switch to branch
git checkout feature-name

# Create and switch
git checkout -b feature-name

# List branches
git branch

# Merge branch into current
git merge feature-name

# Delete branch
git branch -d feature-name
```

---

## npm Commands

### Package Management

```bash
# Install dependencies
npm install

# Install specific package
npm install package-name

# Install as dev dependency
npm install --save-dev package-name

# Uninstall package
npm uninstall package-name

# Update packages
npm update
```

---

### Running Scripts

```bash
# Start dev server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Run tests (if configured)
npm test
```

---

## Terminal Commands

### Navigation

```bash
# Show current directory
pwd

# List files
ls
dir (Windows)

# Change directory
cd folder-name
cd ..        # Go up one level
cd ~         # Go to home directory

# Create directory
mkdir folder-name

# Create file
touch filename.jsx  (Mac/Linux)
type nul > filename.jsx  (Windows)
```

---

### File Operations

```bash
# Copy file
cp source.jsx destination.jsx

# Move/rename file
mv old.jsx new.jsx

# Delete file
rm filename.jsx

# Delete directory
rm -rf directory-name
```

---

## VS Code Shortcuts

### General

```
Open command palette:  Ctrl+Shift+P (Cmd+Shift+P on Mac)
Open terminal:        Ctrl+` (Cmd+` on Mac)
Save file:            Ctrl+S (Cmd+S on Mac)
Save all:             Ctrl+K S (Cmd+K S on Mac)
Close file:           Ctrl+W (Cmd+W on Mac)
```

### Editing

```
Copy line:            Ctrl+C (with nothing selected)
Cut line:             Ctrl+X (with nothing selected)
Duplicate line:       Shift+Alt+Down (Shift+Opt+Down on Mac)
Move line:            Alt+Up/Down (Opt+Up/Down on Mac)
Comment line:         Ctrl+/ (Cmd+/ on Mac)
```

### Navigation

```
Go to file:           Ctrl+P (Cmd+P on Mac)
Go to symbol:         Ctrl+Shift+O (Cmd+Shift+O on Mac)
Go to line:           Ctrl+G (Cmd+G on Mac)
Split editor:         Ctrl+\ (Cmd+\ on Mac)
```

### Search

```
Find:                 Ctrl+F (Cmd+F on Mac)
Find and replace:     Ctrl+H (Cmd+H on Mac)
Find in files:        Ctrl+Shift+F (Cmd+Shift+F on Mac)
```

---

## CSS Quick Reference

### Flexbox

```css
.container {
  display: flex;
  justify-content: center;    /* horizontal */
  align-items: center;        /* vertical */
  gap: 1rem;                  /* space between items */
  flex-wrap: wrap;            /* wrap to next line */
  flex-direction: row;        /* or column */
}
```

---

### Common Properties

```css
/* Spacing */
padding: 1rem;
margin: 1rem;
gap: 1rem;

/* Sizing */
width: 100%;
max-width: 600px;
height: 200px;

/* Colors */
color: #333;
background-color: #fff;

/* Borders */
border: 1px solid #ddd;
border-radius: 8px;

/* Text */
font-size: 1rem;
font-weight: 500;
text-align: center;

/* Transitions */
transition: all 0.3s ease;

/* Shadows */
box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
```

---

## Debugging Tips

### Console Methods

```jsx
// Log values
console.log('Value:', value)

// Log objects
console.log({ name, email, count })

// Styled logs
console.log('%c Important!', 'color: red; font-size: 20px')

// Warnings
console.warn('Warning message')

// Errors
console.error('Error message')

// Table view
console.table(arrayOfObjects)
```

---

### React DevTools

```
1. Install React DevTools browser extension
2. Open DevTools (F12)
3. Click "Components" tab
4. Inspect component props and state
5. Edit values in real-time
```

---

### Common Errors & Solutions

**Error**: `Cannot read property 'map' of undefined`
**Solution**: Check if array exists before mapping
```jsx
{items && items.map(...)}
{items?.map(...)}  // Optional chaining
```

**Error**: `Each child should have a unique "key" prop`
**Solution**: Add key to mapped elements
```jsx
{items.map(item => <div key={item.id}>...</div>)}
```

**Error**: `Cannot find module './Component'`
**Solution**: Check import path and file extension
```jsx
import Component from './components/Component'  // Correct
```

**Error**: `Uncaught ReferenceError: useState is not defined`
**Solution**: Import useState
```jsx
import { useState } from 'react'
```

---

## Project Structure

### Typical React App

```
project-name/
├── node_modules/         # Dependencies (don't touch)
├── public/               # Static files
│   └── vite.svg
├── src/                  # Your code
│   ├── components/       # Reusable components
│   │   ├── Button.jsx
│   │   ├── Button.css
│   │   ├── Card.jsx
│   │   └── Card.css
│   ├── App.jsx          # Main component
│   ├── App.css          # Main styles
│   ├── main.jsx         # Entry point
│   └── index.css        # Global styles
├── .gitignore           # Files to ignore in git
├── index.html           # HTML template
├── package.json         # Dependencies & scripts
├── package-lock.json    # Dependency lock file
├── vite.config.js       # Vite configuration
└── README.md            # Project documentation
```

---

## Environment Variables

### Creating .env File

```bash
# .env file in project root
VITE_API_KEY=your_api_key_here
VITE_SERVICE_ID=service_123
```

### Using in Code

```jsx
const apiKey = import.meta.env.VITE_API_KEY
```

### Important

- Prefix with `VITE_` for Vite projects
- Add `.env` to `.gitignore`
- Never commit secrets to GitHub

---

## Useful Resources

### Documentation

- React: https://react.dev
- Vite: https://vitejs.dev
- MDN (JavaScript): https://developer.mozilla.org
- Git: https://git-scm.com/doc

### Learning

- React Tutorial: https://react.dev/learn
- JavaScript Info: https://javascript.info
- CSS Tricks: https://css-tricks.com

### Tools

- Can I Use (browser support): https://caniuse.com
- Unsplash (free images): https://unsplash.com
- Google Fonts: https://fonts.google.com

---

## Quick Troubleshooting

### Server Won't Start

```bash
# Try:
1. Delete node_modules folder
2. Delete package-lock.json
3. npm install
4. npm run dev
```

### Changes Not Showing

```bash
# Try:
1. Hard refresh browser (Ctrl+Shift+R)
2. Clear browser cache
3. Restart dev server (Ctrl+C, then npm run dev)
```

### Git Issues

```bash
# If git is confused:
git status              # See what's happening
git add .              # Stage everything
git reset --hard       # ⚠️ Discard ALL changes (careful!)
```

### Import Errors

```jsx
// Check:
1. File path is correct
2. File extension matches
3. Export exists in imported file
4. Using correct import syntax

// Examples:
import Component from './Component'        // Default export
import { Component } from './Component'    // Named export
```

---

## Performance Tips

### React Optimization

```jsx
// Don't create functions in render
// Bad ❌
<button onClick={() => handleClick(id)}>

// Good ✅
const handleClickWrapper = () => handleClick(id)
<button onClick={handleClickWrapper}>

// Or use useCallback hook (advanced)
```

### Image Optimization

```jsx
// Specify dimensions
<img src="photo.jpg" width="300" height="200" alt="Description" />

// Use appropriate formats
- JPEG for photos
- PNG for graphics/transparency
- SVG for icons/logos
- WebP for modern browsers
```

---

## Cheat Sheet Print Version

### React Essentials

```jsx
// useState
const [state, setState] = useState(initial)

// Props
function Component({ prop1, prop2 }) { }

// Map
{array.map((item, i) => <div key={i}>{item}</div>)}

// Conditional
{condition && <Component />}

// Event
<button onClick={handler}>Click</button>
```

### Git Essentials

```bash
git status          # Check status
git add .          # Stage all
git commit -m ""   # Commit
git push           # Push to GitHub
```

### Terminal Essentials

```bash
cd folder          # Change directory
ls / dir          # List files
npm install        # Install dependencies
npm run dev       # Start server
```

---

**For detailed explanations, see**: [React Concepts Guide](./06-REACT-CONCEPTS.md)

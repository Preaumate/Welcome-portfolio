# Glossary & JavaScript Fundamentals

**Terms, concepts, and JavaScript features explained**

---

## React Terminology

### Component
A reusable piece of UI. Like a LEGO block - self-contained and can be used multiple times.

```jsx
function Button() {
  return <button>Click</button>
}
```

### JSX
JavaScript XML - lets you write HTML-like code in JavaScript files.

```jsx
const element = <h1>Hello World</h1>
```

### Props
Properties passed from parent to child component.

```jsx
<Card title="Hello" />  // title is a prop
```

### State
Data that a component remembers between renders.

```jsx
const [count, setCount] = useState(0)
```

### Hook
Special function that lets you "hook into" React features. Always starts with `use`.

```jsx
useState, useEffect, useContext
```

### Render
The process of React creating/updating what you see on screen.

### Re-render
When React updates the display because state or props changed.

### Virtual DOM
React's representation of the UI in memory. React compares it to the real DOM to make updates efficient.

---

## JavaScript vs React

### alert()
**Source**: Built-in browser function
**What**: Shows popup dialog

```jsx
alert('Hello!')  // Browser feature, not React
```

### console.log()
**Source**: Built-in browser function
**What**: Logs to browser console (F12)

```jsx
console.log('Debug info')  // Browser feature
```

### useState()
**Source**: React library
**What**: Creates state in a component

```jsx
import { useState } from 'react'  // React feature
const [count, setCount] = useState(0)
```

### onClick
**Source**: React prop (wraps browser onclick)
**What**: Handles click events

```jsx
<button onClick={handleClick}>  // React
<button onclick="handleClick()">  // Plain HTML (not used in React)
```

### map()
**Source**: JavaScript array method
**What**: Transforms array items

```jsx
[1, 2, 3].map(n => n * 2)  // JavaScript feature
```

---

## ES6+ JavaScript Features

### Arrow Functions

**Old way (ES5)**:
```js
function greet(name) {
  return 'Hello ' + name
}
```

**New way (ES6)**:
```js
const greet = (name) => {
  return 'Hello ' + name
}

// Or shorter:
const greet = (name) => 'Hello ' + name

// No parameters:
const sayHi = () => 'Hi!'

// One parameter (parentheses optional):
const double = n => n * 2
```

---

### Template Literals

**Old way**:
```js
const greeting = 'Hello ' + name + ', you are ' + age + ' years old'
```

**New way**:
```js
const greeting = `Hello ${name}, you are ${age} years old`
```

---

### Destructuring

#### Object Destructuring
```js
// Old way
const title = props.title
const description = props.description

// New way
const { title, description } = props

// With default values
const { variant = 'primary' } = props
```

#### Array Destructuring
```js
// Old way
const first = array[0]
const second = array[1]

// New way
const [first, second] = array

// Works with useState!
const [count, setCount] = useState(0)
```

---

### Spread Operator (...)

#### Arrays
```js
const arr1 = [1, 2, 3]
const arr2 = [...arr1, 4, 5]  // [1, 2, 3, 4, 5]

// Add to array
setItems([...items, newItem])
```

#### Objects
```js
const user = { name: 'John', age: 30 }
const updated = { ...user, age: 31 }  // { name: 'John', age: 31 }

// Update state
setFormData({ ...formData, email: 'new@email.com' })
```

---

### Computed Property Names

```js
const propertyName = 'email'

// Old way
const obj = {}
obj[propertyName] = 'test@email.com'

// New way
const obj = {
  [propertyName]: 'test@email.com'
}

// In your code
const { name, value } = e.target
setFormData({
  ...formData,
  [name]: value  // Uses the VALUE of name variable
})
```

---

### Short Property Syntax

```js
const name = 'John'
const age = 30

// Old way
const user = { name: name, age: age }

// New way
const user = { name, age }
```

---

### Optional Chaining (?.)

```js
// Old way - might error if user is undefined
const email = user && user.email

// New way - safe
const email = user?.email

// With arrays
const first = items?.[0]

// With functions
const result = callback?.()
```

---

### Nullish Coalescing (??)

```js
// Old way (falsy check)
const name = userName || 'Guest'  // 'Guest' if userName is '', 0, false, null, undefined

// New way (null/undefined check only)
const name = userName ?? 'Guest'  // 'Guest' only if userName is null or undefined
```

---

## Common JavaScript Methods

### Array Methods

#### map()
Transform each item, returns new array
```js
[1, 2, 3].map(n => n * 2)  // [2, 4, 6]
```

#### filter()
Keep only items that pass test
```js
[1, 2, 3, 4].filter(n => n > 2)  // [3, 4]
```

#### find()
Find first item that matches
```js
[1, 2, 3].find(n => n > 1)  // 2
```

#### includes()
Check if item exists
```js
[1, 2, 3].includes(2)  // true
```

#### join()
Convert array to string
```js
['a', 'b', 'c'].join(', ')  // 'a, b, c'
```

#### push()
Add to end (mutates array)
```js
arr.push(newItem)
```

#### pop()
Remove from end (mutates array)
```js
arr.pop()
```

---

### String Methods

#### toUpperCase() / toLowerCase()
```js
'hello'.toUpperCase()  // 'HELLO'
'HELLO'.toLowerCase()  // 'hello'
```

#### trim()
Remove whitespace
```js
'  hello  '.trim()  // 'hello'
```

#### split()
Convert string to array
```js
'a,b,c'.split(',')  // ['a', 'b', 'c']
```

#### includes()
Check if contains substring
```js
'hello world'.includes('world')  // true
```

#### replace()
Replace text
```js
'hello'.replace('h', 'H')  // 'Hello'
```

---

### Object Methods

#### Object.keys()
Get property names
```js
Object.keys({ a: 1, b: 2 })  // ['a', 'b']
```

#### Object.values()
Get property values
```js
Object.values({ a: 1, b: 2 })  // [1, 2]
```

#### Object.entries()
Get key-value pairs
```js
Object.entries({ a: 1, b: 2 })  // [['a', 1], ['b', 2]]
```

---

## Async JavaScript

### Promises

```js
// Creating a promise
const promise = new Promise((resolve, reject) => {
  if (success) {
    resolve(data)
  } else {
    reject(error)
  }
})

// Using a promise
promise
  .then(data => console.log(data))
  .catch(error => console.error(error))
```

---

### Async/Await

```js
// Old way (promises with .then)
emailjs.send(...)
  .then(result => {
    console.log('Success')
  })
  .catch(error => {
    console.error('Error')
  })

// New way (async/await)
const handleSubmit = async () => {
  try {
    const result = await emailjs.send(...)
    console.log('Success')
  } catch (error) {
    console.error('Error')
  }
}
```

**Rules**:
- Use `async` before function
- Use `await` before promise
- Wrap in try/catch for errors

---

## Web APIs (Browser Features)

### LocalStorage
Store data in browser

```js
// Save
localStorage.setItem('name', 'John')

// Retrieve
const name = localStorage.getItem('name')

// Remove
localStorage.removeItem('name')

// Clear all
localStorage.clear()
```

---

### Fetch API
Make HTTP requests

```js
// GET request
fetch('https://api.example.com/data')
  .then(response => response.json())
  .then(data => console.log(data))

// POST request
fetch('https://api.example.com/data', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ name: 'John' })
})
```

---

### setTimeout / setInterval

```js
// Run once after delay
setTimeout(() => {
  console.log('After 2 seconds')
}, 2000)

// Run repeatedly
const interval = setInterval(() => {
  console.log('Every 2 seconds')
}, 2000)

// Stop interval
clearInterval(interval)
```

---

## Git Terminology

### Repository (Repo)
A project folder tracked by Git.

### Commit
A saved snapshot of your code at a point in time.

### Branch
An independent line of development.

### Main/Master
The primary branch of your repository.

### Remote
The version of your repo on GitHub (or other hosting service).

### Origin
The default name for the remote repository.

### Clone
Download a copy of a repository.

### Fork
Create your own copy of someone else's repository on GitHub.

### Pull Request (PR)
Propose changes to a repository.

### Merge
Combine changes from one branch into another.

### Conflict
When Git can't automatically merge changes.

### Stage/Staging Area
Files prepared for the next commit (`git add`).

### Working Directory
Your local files (not yet staged).

---

## NPM Terminology

### Package
A module/library you can install (like emailjs, react, etc.).

### Dependency
A package your project needs to run.

### Dev Dependency
A package only needed during development (like testing tools).

### node_modules
Folder where all installed packages live.

### package.json
File listing your project's dependencies and scripts.

### package-lock.json
File locking exact versions of dependencies.

---

## HTML/CSS Terminology

### Element
An HTML tag, like `<div>`, `<button>`, `<input>`.

### Attribute
Additional info on an element: `<input type="text" name="email">`.

### Class
CSS class for styling: `<div className="card">`.

### ID
Unique identifier: `<div id="main">`.

### Selector
CSS rule to target elements:
```css
.card { }      /* class */
#main { }      /* ID */
button { }     /* element */
```

### Pseudo-class
CSS for special states:
```css
button:hover { }    /* on hover */
input:focus { }     /* when focused */
li:first-child { }  /* first item */
```

---

## Common Acronyms

**API** - Application Programming Interface
- A way for programs to talk to each other

**AJAX** - Asynchronous JavaScript and XML
- Sending/receiving data without page reload

**DOM** - Document Object Model
- JavaScript representation of HTML

**CDN** - Content Delivery Network
- Fast server for hosting files

**URL** - Uniform Resource Locator
- Web address (https://example.com)

**HTTP/HTTPS** - HyperText Transfer Protocol (Secure)
- How browsers communicate with servers

**JSON** - JavaScript Object Notation
- Data format: `{ "name": "John", "age": 30 }`

**UI** - User Interface
- What users see and interact with

**UX** - User Experience
- How users feel using your app

**IDE** - Integrated Development Environment
- Code editor with extra tools (like VS Code)

---

## File Extensions

**.jsx** - JavaScript file with JSX (React)
**.js** - Regular JavaScript file
**.css** - Stylesheet
**.json** - Data file
**.md** - Markdown documentation
**.html** - HTML file
**.env** - Environment variables

---

## Common Symbols

`{}` - Curly braces: Objects, JSX expressions
`[]` - Square brackets: Arrays, computed properties
`()` - Parentheses: Function calls, grouping
`<>` - Angle brackets: JSX tags, comparison
`=>` - Arrow: Arrow functions
`...` - Spread operator
`?.` - Optional chaining
`??` - Nullish coalescing
`&&` - Logical AND
`||` - Logical OR
`!` - Not/negation
`===` - Strict equality
`!==` - Strict inequality

---

## Code Comments

### JavaScript/React Comments

```jsx
// Single line comment

/*
  Multi-line
  comment
*/

/**
 * Documentation comment
 * @param {string} name - User's name
 * @returns {string} Greeting message
 */
```

### CSS Comments

```css
/* This is a CSS comment */

/*
  Multi-line
  CSS comment
*/
```

### HTML Comments

```html
<!-- This is an HTML comment -->
```

---

## Questions to Ask Yourself

### When Debugging

1. What did I expect to happen?
2. What actually happened?
3. Are there errors in the console? (F12)
4. Did I save the file?
5. Is the dev server running?
6. Did I import/export correctly?
7. Are variable names spelled correctly?

### When Stuck

1. What am I trying to achieve?
2. What have I tried so far?
3. Can I break this into smaller steps?
4. Is there an example I can reference?
5. Should I search the error message?

---

## Learning Resources

### Official Documentation
- React: https://react.dev
- JavaScript (MDN): https://developer.mozilla.org
- Git: https://git-scm.com/doc

### Interactive Learning
- freeCodeCamp: https://www.freecodecamp.org
- JavaScript.info: https://javascript.info
- Scrimba (React): https://scrimba.com

### Videos
- Traversy Media (YouTube)
- Web Dev Simplified (YouTube)
- Net Ninja (YouTube)

### Community
- Stack Overflow: https://stackoverflow.com
- Reddit r/reactjs: https://reddit.com/r/reactjs
- Discord servers (React, JavaScript)

---

## Best Practices Summary

### React
- One component per file
- Use meaningful component names
- Keep components small and focused
- Always provide keys in lists
- Use props for reusability

### JavaScript
- Use `const` by default, `let` when needed, avoid `var`
- Use arrow functions for callbacks
- Use template literals for strings
- Destructure when appropriate
- Handle errors with try/catch

### Git
- Commit often with clear messages
- Push regularly to backup
- Don't commit secrets (.env, API keys)
- Use .gitignore appropriately

### General
- Write code for humans, not just computers
- Comment complex logic
- Use descriptive variable names
- Test as you build
- Ask for help when stuck!

---

**Back to**: [Table of Contents](./README.md)

# Module 4: Building Interactive Components

**Goal**: Create reusable, interactive React components

**Time**: ~2-3 hours

---

## What You'll Build

1. Welcome Dialog (popup greeting)
2. Reusable Button component
3. Card component with images
4. Dropdown selection menu
5. Checkbox group

---

## Component Basics

### What is a Component?

A **component** is a reusable piece of UI.

Think of components like LEGO blocks:
- Each block is self-contained
- You can reuse them multiple times
- Combine them to build complex things

### Component Structure

```jsx
import './ComponentName.css'

function ComponentName() {
  // JavaScript logic here
  
  return (
    // JSX (what to display)
    <div>
      <h1>Component Content</h1>
    </div>
  )
}

export default ComponentName
```

---

## Project Organization

### Create Components Folder

```
src/
├── components/          ← Create this folder
│   ├── Button.jsx
│   ├── Button.css
│   ├── Card.jsx
│   ├── Card.css
│   └── ...
├── App.jsx
└── App.css
```

**Why separate folder?**
- Keeps code organized
- Easy to find components
- Scales as project grows

---

## Component 1: Welcome Dialog

### Create the Component

**File**: `src/components/WelcomeDialog.jsx`

```jsx
import { useState } from 'react'
import './WelcomeDialog.css'

function WelcomeDialog() {
  const [isOpen, setIsOpen] = useState(true)

  if (!isOpen) return null

  return (
    <div className="dialog-overlay">
      <div className="dialog-box">
        <h2>👋 Welcome!</h2>
        <p>Hi! I'm building my first React website.</p>
        <p>Thanks for visiting!</p>
        <button onClick={() => setIsOpen(false)}>
          Enter Site
        </button>
      </div>
    </div>
  )
}

export default WelcomeDialog
```

### Style the Dialog

**File**: `src/components/WelcomeDialog.css`

```css
.dialog-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.7);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.dialog-box {
  background: white;
  padding: 2rem;
  border-radius: 12px;
  max-width: 400px;
  text-align: center;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
}

.dialog-box button {
  margin-top: 1.5rem;
  padding: 0.75rem 2rem;
  background-color: #646cff;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
}

.dialog-box button:hover {
  background-color: #535bf2;
}
```

### Use in App

**File**: `src/App.jsx`

```jsx
import WelcomeDialog from './components/WelcomeDialog'

function App() {
  return (
    <div className="app">
      <WelcomeDialog />
      <h1>Welcome to My Portfolio</h1>
    </div>
  )
}
```

---

## Component 2: Reusable Button

### Create Button Component

**File**: `src/components/Button.jsx`

```jsx
import './Button.css'

function Button({ text, onClick, variant = 'primary' }) {
  return (
    <button className={`custom-button ${variant}`} onClick={onClick}>
      {text}
    </button>
  )
}

export default Button
```

**Key concepts:**
- `{ text, onClick, variant }` = Props (data passed from parent)
- `variant = 'primary'` = Default value
- `{text}` = Display the text prop

### Style Button Variants

**File**: `src/components/Button.css`

```css
.custom-button {
  padding: 0.75rem 1.5rem;
  font-size: 1rem;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.custom-button.primary {
  background-color: #646cff;
  color: white;
}

.custom-button.primary:hover {
  background-color: #535bf2;
  transform: translateY(-2px);
}

.custom-button.secondary {
  background-color: #f0f0f0;
  color: #333;
}

.custom-button.success {
  background-color: #4caf50;
  color: white;
}
```

### Using the Button

```jsx
import Button from './components/Button'

<Button 
  text="Click Me!" 
  onClick={() => alert('Clicked!')} 
  variant="primary" 
/>

<Button 
  text="Secondary" 
  onClick={() => console.log('Clicked')} 
  variant="secondary" 
/>
```

---

## Component 3: Info Card

### Create Card Component

**File**: `src/components/Card.jsx`

```jsx
import './Card.css'

function Card({ title, description, image, imageAlt }) {
  return (
    <div className="card">
      {image && (
        <div className="card-image">
          <img src={image} alt={imageAlt || title} />
        </div>
      )}
      <div className="card-content">
        <h3>{title}</h3>
        <p>{description}</p>
      </div>
    </div>
  )
}

export default Card
```

**Key concepts:**
- `{image && ...}` = Conditional rendering (only show if image exists)
- `imageAlt || title` = Use imageAlt if provided, otherwise use title

### Style the Card

**File**: `src/components/Card.css`

```css
.card {
  background: white;
  border-radius: 12px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  overflow: hidden;
  transition: transform 0.3s ease;
  max-width: 350px;
}

.card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
}

.card-image img {
  width: 100%;
  height: 200px;
  object-fit: cover;
}

.card-content {
  padding: 1.5rem;
}
```

### Using Cards

```jsx
<Card 
  title="Web Development"
  description="I'm learning React!"
  image="https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=500"
  imageAlt="Computer coding"
/>
```

---

## Component 4: Dropdown Menu

### Create Dropdown Component

**File**: `src/components/Dropdown.jsx`

```jsx
import { useState } from 'react'
import './Dropdown.css'

function Dropdown({ label, options, onSelect }) {
  const [selectedValue, setSelectedValue] = useState('')

  const handleChange = (event) => {
    const value = event.target.value
    setSelectedValue(value)
    if (onSelect) {
      onSelect(value)
    }
  }

  return (
    <div className="dropdown-container">
      {label && <label className="dropdown-label">{label}</label>}
      <select 
        className="dropdown-select" 
        value={selectedValue} 
        onChange={handleChange}
      >
        <option value="">-- Please Select --</option>
        {options.map((option, index) => (
          <option key={index} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      {selectedValue && (
        <p className="selected-text">
          You selected: <strong>{selectedValue}</strong>
        </p>
      )}
    </div>
  )
}

export default Dropdown
```

### Using Dropdown

```jsx
const skills = [
  { label: 'JavaScript', value: 'javascript' },
  { label: 'React', value: 'react' },
  { label: 'CSS', value: 'css' }
]

<Dropdown 
  label="Select a skill"
  options={skills}
  onSelect={(value) => console.log('Selected:', value)}
/>
```

---

## Component 5: Checkbox Group

### Create Checkbox Component

**File**: `src/components/CheckboxGroup.jsx`

```jsx
import { useState } from 'react'
import './CheckboxGroup.css'

function CheckboxGroup({ title, options }) {
  const [selectedItems, setSelectedItems] = useState([])

  const handleCheckboxChange = (value) => {
    if (selectedItems.includes(value)) {
      // Remove if already selected
      setSelectedItems(selectedItems.filter(item => item !== value))
    } else {
      // Add if not selected
      setSelectedItems([...selectedItems, value])
    }
  }

  return (
    <div className="checkbox-group">
      <h3>{title}</h3>
      <div className="checkbox-list">
        {options.map((option, index) => (
          <label key={index} className="checkbox-item">
            <input
              type="checkbox"
              value={option.value}
              checked={selectedItems.includes(option.value)}
              onChange={() => handleCheckboxChange(option.value)}
            />
            <span>{option.label}</span>
          </label>
        ))}
      </div>
      {selectedItems.length > 0 && (
        <div className="selected-items">
          <p>Selected: {selectedItems.join(', ')}</p>
        </div>
      )}
    </div>
  )
}

export default CheckboxGroup
```

### Using Checkbox Group

```jsx
const interests = [
  { label: '🎮 Gaming', value: 'gaming' },
  { label: '📚 Reading', value: 'reading' },
  { label: '🎵 Music', value: 'music' }
]

<CheckboxGroup 
  title="My Interests"
  options={interests}
/>
```

---

## Component Patterns

### Pattern 1: Props

Pass data from parent to child:

```jsx
// Parent
<Button text="Click Me" onClick={handleClick} />

// Child receives
function Button({ text, onClick }) {
  return <button onClick={onClick}>{text}</button>
}
```

### Pattern 2: State

Component manages its own data:

```jsx
function Counter() {
  const [count, setCount] = useState(0)
  
  return (
    <button onClick={() => setCount(count + 1)}>
      Count: {count}
    </button>
  )
}
```

### Pattern 3: Conditional Rendering

Show/hide based on condition:

```jsx
{isOpen && <Dialog />}

{user ? <Welcome name={user} /> : <Login />}

{items.length > 0 ? <List items={items} /> : <EmptyState />}
```

### Pattern 4: Lists with map()

Render arrays as components:

```jsx
{items.map((item, index) => (
  <Card key={index} title={item.title} />
))}
```

---

## Component Best Practices

### 1. Single Responsibility
Each component should do ONE thing well.

✅ Good:
- `Button.jsx` - Just handles buttons
- `Card.jsx` - Just handles cards

❌ Bad:
- `Everything.jsx` - Tries to do everything

### 2. Reusability
Design components to be reused:

```jsx
// Good - reusable
<Button text="Save" variant="primary" />
<Button text="Cancel" variant="secondary" />

// Bad - not reusable
<SaveButton />
<CancelButton />
```

### 3. Props Over Hardcoding

```jsx
// Good
function Card({ title }) {
  return <h3>{title}</h3>
}

// Bad
function Card() {
  return <h3>Hardcoded Title</h3>
}
```

### 4. One Component Per File

```
✅ Button.jsx
✅ Card.jsx

❌ Components.jsx (multiple components)
```

---

## Debugging Components

### Common Issues

**Issue**: Component not showing

**Check**:
1. Is it imported? `import Button from './components/Button'`
2. Is it used in JSX? `<Button />`
3. Any console errors? (F12)

**Issue**: Props not working

**Check**:
1. Correct prop names? `text` not `txt`
2. Passing props? `<Button text="Hi" />`
3. Destructuring props? `function Button({ text })`

**Issue**: Styles not applying

**Check**:
1. CSS file imported? `import './Button.css'`
2. className matches? `className="custom-button"`
3. Typo in className?

---

## Testing Your Components

### Manual Testing Checklist

For each component:

1. ✅ Does it render without errors?
2. ✅ Do props work correctly?
3. ✅ Does interaction work? (clicks, etc.)
4. ✅ Does styling look good?
5. ✅ Does it work on different screen sizes?

---

## What You've Learned

✅ Creating reusable components
✅ Using props to pass data
✅ Managing state with useState
✅ Conditional rendering
✅ Rendering lists with map()
✅ Component organization
✅ Styling components

---

## Practice Exercises

1. **Create a Badge component**
   - Takes `text` and `color` props
   - Small pill-shaped design

2. **Create a ProgressBar component**
   - Takes `percentage` prop
   - Shows visual progress

3. **Modify existing components**
   - Add more button variants
   - Add icons to cards

---

## What's Next?

✅ Built 5 interactive components
✅ Understand component patterns
✅ Can create new components

**Next**: [Module 5 - Contact Form & Email Integration](./05-CONTACT-FORM.md)

---

## Quick Component Template

```jsx
import './ComponentName.css'

function ComponentName({ prop1, prop2 }) {
  // State and logic here
  
  return (
    <div className="component-name">
      {/* JSX here */}
    </div>
  )
}

export default ComponentName
```
